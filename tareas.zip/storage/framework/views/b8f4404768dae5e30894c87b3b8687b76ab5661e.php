<?php $__env->startSection('page_heading','Reportes Usuarios'); ?>

<?php $__env->startSection('section'); ?>

    <div class="col-sm-12">

        <div class="row">
            <?php echo Form::open (['id'=>'formSearch']); ?>

            <div class='col-sm-3'>
                <div class="form-group">
                    <?php echo Form::label('start','Desde'); ?>

                    <div class='input-group date' id='start_datetimepicker'>
                        <?php echo Form::text('start',$start,['class'=>'form-control']); ?>

                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>
            </div>
            <div class='col-sm-3'>
                <div class="form-group">
                    <?php echo Form::label('end','Hasta'); ?>

                    <div class='input-group date' id='end_datetimepicker'>
                        <?php echo Form::text('end',$end,['class'=>'form-control']); ?>

                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <?php echo Form::label('buscar','Buscar'); ?>

                <div class="input-group">
                    <?php echo Form::select('trabajador',$trabajadores,$trabajador,['placeholder'=>'Seleccione trabajador','class'=>'form-control','id'=>'trabajador']); ?>

                    <span class="input-group-btn">
                        <a href="#!" id="search" class="btn btn-primary" title="Buscar"><i class="fa fa-search" aria-hidden="true"></i>
                        </a>
                    </span>
                </div><!-- /input-group -->
                    </div>
            </div><!-- /.col-lg-3 -->
            <div class="col-sm-3">
                <div class="form-group pull-right">
<?php /*                    <?php echo Form::label('export','Exportar'); ?>*/ ?>
                    <div >

                        <?php /*<a href="<?php echo e(route('admin.tasks.reports.users.excel')); ?>"  class="btn btn-success" title="exportar"><i class="fa fa-file-excel-o" aria-hidden="true"></i>*/ ?>
                        <?php /*</a>*/ ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div id="list-user"></div>
            </div>

            <?php echo Form::close(); ?>

        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script type="text/javascript">
        $(function () {
            $('#start_datetimepicker').datetimepicker({
                showClear:true,
                showClose:true,
                locale:'es',
                format:'YYYY-MM-DD'

            });
            $('#end_datetimepicker').datetimepicker({
                useCurrent: false,
                showClear:true,
                showClose:true,
                locale:'es',
                format:'YYYY-MM-DD'

            });
            $("#start_datetimepicker").on("dp.change", function (e) {
                $('#end_datetimepicker').data("DateTimePicker").minDate(e.date);

            });
            $("#end_datetimepicker").on("dp.change", function (e) {
                $('#start_datetimepicker').data("DateTimePicker").maxDate(e.date);
            });


        });

        $(function () {
        $("#search").click(function(){

            var token = document.getElementsByName("_token")[0].value;
            var start=$("#start").val();
            var end=$("#end").val( );
            var trabajador = $("#trabajador option:selected").val();
            var datos={
                start:start,
                end:end,
                trabajador:trabajador
            };
            var route= "<?php echo e(route('admin.tasks.reports.users')); ?>";
            $.ajax({
                url: route,
                type: "POST",
                headers: {'X-CSRF-TOKEN': token},
                contentType: 'application/x-www-form-urlencoded',
                data: { start:start, end:end, trabajador:trabajador},
                success: function(data) {
                    $("#list-user").empty().html(data);
                },
                error: function(data){

                }
            });
        });

        <?php /*$("#export-exel").click(function(){*/ ?>
            <?php /*var token = document.getElementsByName("_token")[0].value;*/ ?>
            <?php /*var start=$("#start").val();*/ ?>
            <?php /*var end=$("#end").val( );*/ ?>
            <?php /*var trabajador = $("#trabajador option:selected").val();*/ ?>
            <?php /*var datos={*/ ?>
                <?php /*start:start,*/ ?>
                <?php /*end:end,*/ ?>
                <?php /*trabajador:trabajador*/ ?>
            <?php /*};*/ ?>

            <?php /*var route= "<?php echo e(route('admin.tasks.reports.users.excel')); ?>";*/ ?>
            <?php /*$.ajax({*/ ?>
                <?php /*url: route,*/ ?>
                <?php /*type: "GET",*/ ?>
                <?php /*headers: {'X-CSRF-TOKEN': token},*/ ?>
                <?php /*contentType: 'application/x-www-form-urlencoded',*/ ?>
                <?php /*data: { start:start, end:end, trabajador:trabajador},*/ ?>
                <?php /*success: function(data) {*/ ?>
                        <?php /*$("#list-user").empty().html(data);*/ ?>
                <?php /*},*/ ?>
                <?php /*error: function(data){*/ ?>

                <?php /*}*/ ?>
            <?php /*});*/ ?>
//        });

        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
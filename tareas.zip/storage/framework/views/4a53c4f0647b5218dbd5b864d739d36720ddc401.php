<?php $__env->startSection('page_heading', 'Permiso'); ?>

<?php $__env->startSection('section'); ?>

    <div class="row">
        <div class="col s12">
            <div>
                <table class="table table-striped table-bordered table-condensed table-hover highlight responsive-table">
                    <thead>
                    <th>Id</th>
                    <th>Permiso</th>
                    <th>Nombre para mostrar</th>
                    <th>Descripción</th>
                    <th>Creado</th>
                    <th>Modificado</th>
                    <th>Opciones</th>
                    </thead>
                        <tr>
                            <td><?php echo e($per->id); ?></td>
                            <td><?php echo e($per->name); ?></td>
                            <td><?php echo e($per->display_name); ?></td>
                            <td><?php echo e($per->description); ?></td>
                            <td><?php echo e($per->created_at); ?></td>
                            <td><?php echo e($per->updated_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.permissions.index')); ?>">
                                    <?php echo Form::button('<i class="fa fa-undo"></i>',['class'=>'btn ']); ?>

                                </a>
                            </td>
                        </tr>
                  </table><!--end table-responsive-->
            </div><!-- end div ./table-responsive-->
        </div><!--end div ./col-lg-12. etc-->
    </div><!--end div ./row-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
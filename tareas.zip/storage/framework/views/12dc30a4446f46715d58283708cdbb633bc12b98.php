<?php $__env->startSection('body'); ?>
<div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
            <br /><br /><br />
               <?php /*<?php $__env->startSection('login_panel_title','Please Sign In'); ?>*/ ?>
               <?php /*<?php $__env->startSection('login_panel_body'); ?>*/ ?>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <h3 class="panel-title">Acceder al sistema</h3>
                        <?php echo $__env->make('alert.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php /*Para la act por email*/ ?>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('warning')): ?>
                            <div class="alert alert-warning">
                                <?php echo e(session('warning')); ?>

                            </div>
                        <?php endif; ?>
                        <?php /*end act x email*/ ?>

                    </div>
                    <div class="panel-body">
                        <?php echo Form::open(['url'=>'/login','method'=>'POST','role'=>'form']); ?>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'Correo','autofocus']); ?>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <?php echo Form::password('password',['class'=>'form-control','placeholder'=>'Contraseña']); ?>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-inline">
                                <div class="form-group">
                                    <?php echo Form::checkbox('remember',null); ?>

                                    <?php echo Form::label('remember','Recordarme'); ?>

                                </div>
                            </div>
                    </div>
                    <div class="panel-footer">


                        <?php echo Form::button('<i class="fa fa-sign-in fa-fw"></i>Entrar',['class'=>'btn btn-primary pull-left','type'=>'submit']); ?>

                        <?php echo Form::close(); ?>

                        <a class="btn btn-link pull-right" href="<?php echo e(url('/password/reset')); ?>">Olvide mi contraseña</a><br>
                        <div class="clearfix"></div>
                    </div>

                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plane', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
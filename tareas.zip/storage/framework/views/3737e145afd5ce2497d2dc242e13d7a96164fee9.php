<?php $__env->startSection('page_heading','Cambiar Contraseña'); ?>

<?php $__env->startSection('section'); ?>
    <div class="col-sm-12">
        <div class="row">
            <?php echo Form::model($user,['route'=>['user.profile.update',$user], 'method'=>'PUT','role'=>'form']); ?>

            <div class="col-lg-4 col-md-6 col-sm-12 col-lg-offset-1">
                <?php echo $__env->make('alert.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('alert.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="form-group">
                    <?php echo form::label('password','Contraseña anterior:*'); ?>

                    <?php echo Form::password('password',['class'=>'form-control', 'placeholder'=>'******']); ?>

                </div>
                <div class="form-group">
                    <?php echo form::label('password_new','Nueva contraseña:'); ?>

                    <?php echo Form::password('password_new',['class'=>'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo form::label('password_new','Confirmar contraseña:'); ?>

                    <?php echo Form::password('password_new_confirmation',['class'=>'form-control']); ?>

                </div>
                <div class="form-group pull-right">
                    <div class="clerafix"></div>
                    <?php echo Form::submit('Actualizar',['class'=>'btn btn-warning','type'=>'button']); ?>

                    <?php echo Form::reset('Cancelar',['class'=>'btn btn-success']); ?>

                    <a href="<?php echo e(route('user.profile')); ?>">
                        <?php echo Form::button('Regresar',['class'=>'btn btn-primary']); ?>

                    </a>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
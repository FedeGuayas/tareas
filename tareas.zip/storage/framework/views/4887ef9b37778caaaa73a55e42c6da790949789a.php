<?php $__env->startSection('page_heading','Listado de Tareas'); ?>

<?php $__env->startSection('section'); ?>
    <div class="col-sm-12 col-lg-6">
        <div class="row">
            <a href="<?php echo e(route('admin.tasks.create' )); ?>" class="btn btn-success tip pull-left" data-placement="right"
               title="Nueva"><i class="fa fa-tasks" aria-hidden="true"></i>
                Nueva</a>
        </div>
    </div>

    <div class="col-sm-12">
        <?php echo $__env->make('alert.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="msg-send" class="alert alert-success alert-dismissible" role="alert" style="display: none">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong id="send"></strong></div>
        <div class="row">
            <div class="col-lg-12">

                <table id="task_table" class="table table-striped table-bordered" cellspacing="0" width="100%"
                       data-order='[[ 0, "asc" ]]' style="display: none">
                    <thead>
                    <tr>
                        <?php /*<th>id</th>*/ ?>
                        <th>Tarea</th>
                        <th>Trabajador</th>
                        <th>Area</th>
                        <th>Inicio</th>
                        <th>Termino P</th>
                        <th>Termino R</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <?php /*<th>id</th>*/ ?>
                        <th>Tarea</th>
                        <th>Trabajador</th>
                        <th>Area</th>
                        <th>Inicio</th>
                        <th>Termino P</th>
                        <th>Termino R</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php foreach($tasks as $task): ?>
                        <tr>
                            <?php /*<td><?php echo e($area->id); ?></td>*/ ?>
                            <td><?php echo e($task->task); ?></td>
                            <td><?php echo e($task->user->getFullName()); ?></td>
                            <td>
                                <?php foreach($areas as $area): ?>
                                    <?php /* $task->user->area_id //area del usuario*/ ?>
                                    <?php if($task->user->area_id==$area->id): ?>
                                        <?php echo e($area->area); ?><br><br>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </td>
                            <td><?php echo e($task->start_day); ?></td>
                            <td><?php echo e($task->performance_day); ?></td>
                            <td><?php echo e($task->end_day); ?></td>
                            <td>
                                <?php if($task->state==0): ?>
                                    <span class="label label-warning">Activa</span>

                                <?php else: ?>
                                    <?php if($task->end_day > $task->performance_day): ?>
                                        <span class="label label-danger">Terminada</span>
                                    <?php else: ?>
                                        <span class="label label-success">Terminada</span>
                                    <?php endif; ?>

                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if($task->repeats==0): ?>
                                    <a href="<?php echo e(route('admin.tasks.edit', $task )); ?>" class="btn btn-xs btn-warning" data-placement="top" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.calendar.edit', $task)); ?>" class="btn btn-xs btn-warning" data-placement="top" title="Editar"><i class="fa fa-calendar" aria-hidden="true"></i>
                                    </a>
                                <?php endif; ?>
                                <a href="" data-target="#modal-delete-<?php echo e($task->id); ?>" data-toggle="modal" class="btn btn-xs btn-danger" data-placement="top" title="Elimminar"><i class="fa fa-trash" aria-hidden="true"></i>
                                </a>
                                    <?php if(!is_null($task->end_day) && ($task->state==0)): ?>
                                        <a href="" id="<?php echo e($task->id); ?>" class="btn btn-xs btn-primary aprobEndTask" data-placement="top" title="Aprobar"><i class="fa fa-thumbs-up" aria-hidden="true"></i>
                                        </a>
                                    <?php endif; ?>
                            </td>
                        </tr>
                        <?php echo $__env->make('tasks.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endforeach; ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
    <?php echo Form::open(['id' =>'form-taskEndAprob']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script type="text/javascript">

        $(document).ready(function () {

            var table = $('#task_table').DataTable({
                "lengthMenu": [[5, 7, 10, 25], [5, 7, 10, 25]],
                "processing": true,
//            "serverSide": false,
//            "ajax":"api/result",
//            "columns":[
//                {data:'first_name'},
//                {data:'second_name'},
//                {data:'last_name'},
//                {data:'sex'},
//                {data:'category'},
//                {data:'circuit'},
//                {data:'place'},
//                {data:'time'},
//            ],
//            select: true
                "language": {
                    "decimal": "",
                    "emptyTable": "No se encontraron datos en la tabla",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
                    "infoEmpty": "Mostrando 0 a 0 de 0 registros",
                    "infoFiltered": "(filtrados de un total _MAX_ registros)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ registros",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",
                    "zeroRecords": "No se encrontraron coincidencias",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    },
                    "aria": {
                        "sortAscending": ": Activar para ordenar ascendentemente",
                        "sortDescending": ": Activar para ordenar descendentemente"
                    }
                },
                "fnInitComplete": function () {
                    $('#task_table').fadeIn();
                }
            });


            $(function () {
                $(".tip1").tooltip()
            });
        });

        $(".aprobEndTask").click(function(e){
            e.preventDefault();
            var token = document.getElementsByName("_token")[0].value;
            var datos=this.id;
            var route="<?php echo e(route('user.task.end.aprob')); ?>";
            $.ajax({
                url: route,
                type: "POST",
                headers: {'X-CSRF-TOKEN': token},
                contentType: 'application/x-www-form-urlencoded',
                data: {datos},
                success: function(json) {
                    console.log(json);
                    $("#send").html(json.message);
                    $("#msg-send").fadeIn();
                },
                error: function(json){
                    console.log("Error al enviar id");
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
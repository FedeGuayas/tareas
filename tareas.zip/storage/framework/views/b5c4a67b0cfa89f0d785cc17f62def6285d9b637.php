<?php $__env->startSection('page_heading','Editar Trabajador'); ?>

<?php $__env->startSection('section'); ?>
    <div class="col-sm-12">
        <div class="row">

                <?php echo Form::model($user,['route'=>['admin.users.update',$user->id], 'method'=>'PUT','role'=>'form']); ?>


                <div class="col-lg-6 col-md-6 col-sm-12 col-lg-offset-1">
                    <div class="form-horizontal">
                        <div class="form-group">
                            <div class="form-inline">
                                <?php echo Form::label('first_name','Nombre:'); ?>

                                <?php echo Form::text('first_name',null,['class'=>'form-control','placeholder'=>'Nombres','required']); ?>

                                <?php echo Form::text('last_name',null,['class'=>'form-control','placeholder'=>'Apellidos','required']); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-inline">
                                <div class="form-group">
                                    <?php echo Form::label('phone','Teléfono:'); ?>

                                    <?php echo Form::text('phone',null,['class'=>'form-control','placeholder'=>'Teléfono']); ?>

                                    <div class="input-group">
                                        <span class="input-group-addon" id="email-add">@</span>
                                        <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'correo@ejemplo.com','aria-describedby'=>'email-add']); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-inline">
                                <?php echo Form::label('area_id','Area:'); ?>

                                <?php echo Form::select('area_id',$areas,$user->area_id,['class'=>'form-control','placeholder'=>'Seleccione el area...','required']); ?>

                            </div>
                        </div>
                        <div class="form-group pull-right">
                            <div class="clerafix"></div>
                            <?php echo Form::submit('Editar',['class'=>'btn btn-warning','type'=>'button']); ?>

                            <?php echo Form::reset('Cancelar',['class'=>'btn btn-success']); ?>

                            <a href="<?php echo e(route('admin.users.index')); ?>">
                                <?php echo Form::button('Regresar',['class'=>'btn btn-primary']); ?>

                            </a>

                        </div>
                    </div>
                </div>

                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
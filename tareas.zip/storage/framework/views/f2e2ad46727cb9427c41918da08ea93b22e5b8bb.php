<div class="col-lg-12">
    <table class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
        <tr>
            <?php /*<th>id</th>*/ ?>
            <th>Trabajador</th>
            <th>Area</th>
            <th>Tareas</th>
            <th>Cumplidas</th>
            <th>Sin cumplir</th>

        </tr>
        </thead>
        <tbody>
        <?php /*<?php foreach($users as $user): ?>*/ ?>
        <tr>
            <td><?php echo e($user->getfullName()); ?></td>
            <td><?php echo e($user->area->area); ?></td>
            <td><?php foreach($tareas as $task): ?>
                    <?php echo e($task->task); ?><br>
                <?php endforeach; ?>
            </td>
            <td><?php echo e($cumplidas); ?></td>
            <td><?php echo e($incumplidas); ?></td>
        </tr>

        <?php /*<?php endforeach; ?>*/ ?>
        </tbody>
    </table>
</div>
<?php $__env->startSection('page_heading','Listado Roles'); ?>

<?php $__env->startSection('section'); ?>

    <div class="row">
        <div class="col l8 m8 s">
            <?php echo $__env->make('alert.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <h4>Listado de Roles</h4>
            <?php /* <?php echo $__env->make('runner.usuarios.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>
        </div>
    </div>

    <div class="row">
        <div class="col s12">
            <div class="">
                <a href="<?php echo e(route('admin.roles.create')); ?>">
                    <?php echo Form::button('<i class="fa fa-plus fa-fw"></i>Crear',['class'=>'btn btn-success']); ?>

                </a>
                <table class="table table-striped table-bordered table-condensed table-hover highlight responsive-table">
                    <thead>
                    <th>Id</th>
                    <th>Rol</th>
                    <th>Descripción</th>
                    <th>Permisos</th>
                    <th>Opciones</th>
                    </thead>
                    <?php foreach($roles as $rol): ?>
                        <tr>
                            <td><?php echo e($rol->id); ?></td>
                            <td><?php echo e($rol->display_name); ?></td>
                            <td><?php echo e($rol->description); ?></td>
                            <td>
                                <?php foreach($rol->perms as $per): ?>
                                    <?php echo e($per->display_name); ?><br>
                                <?php endforeach; ?>
                            </td>

                            <td>
                                <?php echo Form::button('<i class="fa fa-trash-o" ></i>',['class'=>'btn btn-xs btn-danger','data-target'=>"modal-delete-$rol->id"]); ?>

                                <a href="<?php echo e(route('admin.roles.edit', $rol->id )); ?>">
                                    <?php echo Form::button('<i class="fa fa-pencil-square-o" ></i>',['class'=>'btn btn-xs btn-primary']); ?>

                                </a>
                                <a href="<?php echo e(route('admin.roles.show', $rol->id )); ?>">
                                    <?php echo Form::button('<i class="fa fa-eye fa-fw"></i>',['class'=>'btn btn-xs btn-info']); ?>

                                </a>
                                <a href="<?php echo e(route('admin.roles.permisos',$rol->id  )); ?>">
                                    <?php echo Form::button('<i class="fa fa-key fa-fw"></i>',['class'=>'btn btn-xs btn-success']); ?>

                                </a>

                            </td>
                        </tr>
                        <?php echo $__env->make('roles.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endforeach; ?>
                </table><!--end table-responsive-->
            </div><!-- end div ./table-responsive-->
        </div><!--end div ./col-lg-12. etc-->
    </div><!--end div ./row-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<html>
    <body>
        <div>
            <p>
               Estimado, se le ha creado una cuenta en el sistema de Gestión de Tareas.
            </p>
            <p>
                Debe dar clic en el siguiente link para activar su cuenta
                <?php echo e($link); ?>

            </p>
            <p>
                Este enlace será de un solo uso
            </p>
            <p>
                Sus datos de acceso son:
                usuario: <?php echo e($user->email); ?>

                contraseña: <?php echo e($passw); ?>

            </p>

        </div>
    </body>
</html>
<?php $__env->startSection('page_heading','Reportes Tareas'); ?>

<?php $__env->startSection('section'); ?>

    <div class="col-sm-12">

        <div class="row">
            <?php echo $__env->make('reports.task-search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-sm-3">
                <div class="form-group pull-right">
                    <?php /*<?php echo Form::label('export','Exportar'); ?>*/ ?>
                        <?php echo $__env->make('reports.export-tasks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php /*<a href="<?php echo e(route('admin.tasks.reports.users.excel')); ?>"  class="btn btn-success" title="exportar"><i class="fa fa-file-excel-o" aria-hidden="true"></i>*/ ?>
                        <?php /*</a>*/ ?>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-12">
                    <table id="tasks_table" class="table table-striped table-bordered" cellspacing="0" width="100%"
                           data-order='[[ 1, "asc" ]]' style="display: none">
                        <thead>
                        <tr>
                            <?php /*<th>id</th>*/ ?>
                            <th>Tarea</th>
                            <th>Trabajador</th>
                            <th>Area</th>
                            <th>Inicio</th>
                            <th>Termino P</th>
                            <th>Termino R</th>

                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <?php /*<th>id</th>*/ ?>
                            <th>Tarea</th>
                            <th>Trabajador</th>
                            <th>Area</th>
                            <th>Inicio</th>
                            <th>Termino P</th>
                            <th>Termino R</th>

                        </tr>
                        </tfoot>
                        <tbody>
                        <?php foreach($tasks as $task): ?>
                            <tr>
                                <?php /*<td><?php echo e($area->id); ?></td>*/ ?>
                                <td><?php echo e($task->task); ?></td>
                                <td><?php echo e($task->user->getFullName()); ?></td>
                                <td>
                                    <?php foreach($areas as $area): ?>
                                        <?php /* $task->user->area_id //area del usuario*/ ?>
                                        <?php if($task->user->area_id==$area->id): ?>
                                            <?php echo e($area->area); ?><br>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </td>
                                <td><?php echo e($task->start_day); ?></td>
                                <td><?php echo e($task->performance_day); ?></td>
                                <td><?php echo e($task->end_day); ?></td>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            </div>


        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script type="text/javascript">
        $(function () {
            $('#start_datetimepicker').datetimepicker({
                showClear:true,
                showClose:true,
                locale:'es',
                format:'YYYY-MM-DD'

            });
            $('#end_datetimepicker').datetimepicker({
                useCurrent: false,
                showClear:true,
                showClose:true,
                locale:'es',
                format:'YYYY-MM-DD'

            });
            $("#start_datetimepicker").on("dp.change", function (e) {
                $('#end_datetimepicker').data("DateTimePicker").minDate(e.date);

            });
            $("#end_datetimepicker").on("dp.change", function (e) {
                $('#start_datetimepicker').data("DateTimePicker").maxDate(e.date);
            });
        });

        var table =  $('#tasks_table').DataTable({
            "lengthMenu": [[5, 7, 10, 25], [5, 7, 10, 25]],
            "processing": true,
//            "serverSide": false,
//            "ajax":"api/result",
//            "columns":[
//                {data:'first_name'},
//                {data:'second_name'},
//                {data:'last_name'},
//                {data:'sex'},
//                {data:'category'},
//                {data:'circuit'},
//                {data:'place'},
//                {data:'time'},
//            ],
//            select: true
            "language":{
                "decimal":        "",
                "emptyTable":     "No se encontraron datos en la tabla",
                "info":           "Mostrando _START_ a _END_ de _TOTAL_ registros",
                "infoEmpty":      "Mostrando 0 a 0 de 0 registros",
                "infoFiltered":   "(filtrados de un total _MAX_ registros)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     "Mostrar _MENU_ registros",
                "loadingRecords": "Cargando...",
                "processing":     "Procesando...",
                "search":         "Buscar:",
                "zeroRecords":    "No se encrontraron coincidencias",
                "paginate": {
                    "first":      "Primero",
                    "last":       "Ultimo",
                    "next":       "Siguiente",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": Activar para ordenar ascendentemente",
                    "sortDescending": ": Activar para ordenar descendentemente"
                }
            },
            "fnInitComplete":function(){
                $('#tasks_table').fadeIn();
            }
        });




    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
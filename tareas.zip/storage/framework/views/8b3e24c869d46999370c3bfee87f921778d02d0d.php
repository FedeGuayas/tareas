<?php $__env->startSection('body'); ?>
 <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(url ('/')); ?>">Control de Tareas. V1.0</a>
            </div>
            <!-- /.navbar-header -->

            <!--MEN MENSAJES DROPDOWN-->
            <ul class="nav navbar-top-links navbar-right">



               <!--MENU DROPDOWN TAREAS-->
                <?php /*<li class="dropdown">*/ ?>
                    <?php /*<a class="dropdown-toggle" data-toggle="dropdown" href="#">*/ ?>
                        <?php /*<i class="fa fa-tasks fa-fw"></i>  <i class="fa fa-caret-down"></i>*/ ?>
                    <?php /*</a>*/ ?>
                    <?php /*<ul class="dropdown-menu dropdown-tasks">*/ ?>
                        <?php /*<li>*/ ?>
                            <?php /*<a href="#">*/ ?>
                                <?php /*<div>*/ ?>
                                    <?php /*<p>*/ ?>
                                        <?php /*<strong>Trea 1</strong>*/ ?>
                                        <?php /*<span class="pull-right text-muted">40%</span>*/ ?>
                                    <?php /*</p>*/ ?>

                                        <?php /*<div>*/ ?>
                                        <?php /*<?php echo $__env->make('widgets.progress', array('animated'=> true, 'class'=>'success', 'value'=>'40'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>
                                            <?php /*<span class="sr-only">40%</span>*/ ?>
                                        <?php /*</div>*/ ?>

                                <?php /*</div>*/ ?>
                            <?php /*</a>*/ ?>
                        <?php /*</li>*/ ?>
                        <?php /*<li class="divider"></li>*/ ?>
                        <?php /*<li>*/ ?>
                            <?php /*<a href="#">*/ ?>
                                <?php /*<div>*/ ?>
                                    <?php /*<p>*/ ?>
                                        <?php /*<strong>Tarea 2</strong>*/ ?>
                                        <?php /*<span class="pull-right text-muted">20%</span>*/ ?>
                                    <?php /*</p>*/ ?>

                                        <?php /*<div>*/ ?>
                                        <?php /*<?php echo $__env->make('widgets.progress', array('animated'=> true, 'class'=>'info', 'value'=>'20'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>
                                            <?php /*<span class="sr-only">20% </span>*/ ?>
                                        <?php /*</div>*/ ?>

                                <?php /*</div>*/ ?>
                            <?php /*</a>*/ ?>
                        <?php /*</li>*/ ?>
                        <?php /*<li class="divider"></li>*/ ?>
                        <?php /*<li>*/ ?>
                            <?php /*<a href="#">*/ ?>
                                <?php /*<div>*/ ?>
                                    <?php /*<p>*/ ?>
                                        <?php /*<strong>Tarea 3</strong>*/ ?>
                                        <?php /*<span class="pull-right text-muted">60%</span>*/ ?>
                                    <?php /*</p>*/ ?>

                                        <?php /*<div>*/ ?>
                                        <?php /*<?php echo $__env->make('widgets.progress', array('animated'=> true, 'class'=>'warning', 'value'=>'60'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>
                                            <?php /*<span class="sr-only">60%</span>*/ ?>
                                        <?php /*</div>*/ ?>

                                <?php /*</div>*/ ?>
                            <?php /*</a>*/ ?>
                        <?php /*</li>*/ ?>
                        <?php /*<li class="divider"></li>*/ ?>
                        <?php /*<li>*/ ?>
                            <?php /*<a href="#">*/ ?>
                                <?php /*<div>*/ ?>
                                    <?php /*<p>*/ ?>
                                        <?php /*<strong>Tarea 4</strong>*/ ?>
                                        <?php /*<span class="pull-right text-muted">80%</span>*/ ?>
                                    <?php /*</p>*/ ?>

                                        <?php /*<div>*/ ?>
                                        <?php /*<?php echo $__env->make('widgets.progress', array('animated'=> true,'class'=>'danger', 'value'=>'80'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>
                                            <?php /*<span class="sr-only">80% </span>*/ ?>
                                        <?php /*</div>*/ ?>

                                <?php /*</div>*/ ?>
                            <?php /*</a>*/ ?>
                        <?php /*</li>*/ ?>
                        <?php /*<li class="divider"></li>*/ ?>
                        <?php /*<li>*/ ?>
                            <?php /*<a class="text-center" href="#">*/ ?>
                                <?php /*<strong>Ver Todas las Tareas</strong>*/ ?>
                                <?php /*<i class="fa fa-angle-right"></i>*/ ?>
                            <?php /*</a>*/ ?>
                        <?php /*</li>*/ ?>
                    <?php /*</ul>*/ ?>
                    <?php /*<!-- /.dropdown-tasks -->*/ ?>
                <?php /*</li>*/ ?>
                <!-- /.dropdown -->



                <!--MENU DROPDOWN ALERTAS-->
                <?php /*<li class="dropdown">*/ ?>
                    <?php /*<a class="dropdown-toggle" data-toggle="dropdown" href="#">*/ ?>
                        <?php /*<i class="fa fa-bell fa-fw"></i>  <i class="fa fa-caret-down"></i>*/ ?>
                    <?php /*</a>*/ ?>
                    <?php /*<ul class="dropdown-menu dropdown-alerts">*/ ?>
                        <?php /*<?php foreach(Auth::user()->$notifications as $notification): ?>*/ ?>
                        <?php /*<li>*/ ?>
                            <?php /*<a href="#">*/ ?>
                                <?php /*<div>*/ ?>
                                    <?php /*<i class="fa fa-tasks fa-fw"></i>*/ ?>
                                    <?php /*<?php echo e($notification->name); ?>*/ ?>
                                    <?php /*<span class="pull-right text-muted small">*/ ?>
<?php /*                                        <?php echo e($notification->created_at->diffForHumans()); ?>*/ ?>
                                    <?php /*</span>*/ ?>
                                <?php /*</div>*/ ?>
                            <?php /*</a>*/ ?>
                        <?php /*</li>*/ ?>
                        <?php /*<?php endforeach; ?>*/ ?>
                        <?php /*<li class="divider"></li>*/ ?>

                        <?php /*<li>*/ ?>
                            <?php /*<a class="text-center" href="#">*/ ?>
                                <?php /*<strong>Ver Todas</strong>*/ ?>
                                <?php /*<i class="fa fa-angle-right"></i>*/ ?>
                            <?php /*</a>*/ ?>
                        <?php /*</li>*/ ?>
                    <?php /*</ul>*/ ?>
                    <?php /*<!-- /.dropdown-alerts -->*/ ?>
                <?php /*</li>*/ ?>
                <!-- /.dropdown -->



                <!--MENU DROPDOWN DE USUARIOS-->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <?php echo e(Auth::user()->name); ?> <i class="fa fa-caret-down"></i>

                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="<?php echo e(route ('user.profile')); ?>"><i class="fa fa-user fa-fw"></i>Perfil</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-sign-out fa-fw"></i>Salir</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->


            <!--BARRA LATERAL-->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li <?php echo e((Request::is('home') ? 'class="active"' : '')); ?>>
                            <a href="<?php echo e(url ('/home')); ?>"><i class="fa fa-home fa-fw"></i> Home</a>
                        </li>
                        <?php /*<li <?php echo e((Request::is('*charts') ? 'class="active"' : '')); ?>>*/ ?>
                            <?php /*<a href="#!"><i class="fa fa-bar-chart-o fa-fw"></i> Gráficas</a>*/ ?>
                            <?php /*<ul class="nav nav-second-level">*/ ?>
                                <?php /*<li>*/ ?>
                                    <?php /*<a href="#!">Grafica tipo 1</a>*/ ?>
                                <?php /*</li>*/ ?>
                                <?php /*<li>*/ ?>
                                    <?php /*<a href="#!">Grafica tipo 2</a>*/ ?>
                                <?php /*</li>*/ ?>
                                <?php /*<li>*/ ?>
                                    <?php /*<a href="#!">Grafica tipo 3</a>*/ ?>
                                <?php /*</li>*/ ?>
                            <?php /*</ul>*/ ?>
                            <?php /*<!-- /.nav-second-level -->*/ ?>
                        <?php /*</li>*/ ?>
                        <?php /*<li <?php echo e((Request::is('*tables') ? 'class="active"' : '')); ?>>*/ ?>
                            <?php /*<a href="<?php echo e(url ('tables')); ?>"><i class="fa fa-table fa-fw"></i> Tablas</a>*/ ?>
                        <?php /*</li>*/ ?>
                        <?php /*<li <?php echo e((Request::is('*forms') ? 'class="active"' : '')); ?>>*/ ?>
                            <?php /*<a href="<?php echo e(url ('forms')); ?>"><i class="fa fa-edit fa-fw"></i> Forms</a>*/ ?>
                        <?php /*</li>*/ ?>
                        <li >
                            <a href="#"><i class="fa fa-files-o" aria-hidden="true"></i> Reportes<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('admin.tasks.reports.users')); ?>">Tareas por trabajadores</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('admin.reports.index')); ?>">Informe Excel</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href="#"><i class="fa fa-cogs" aria-hidden="true"></i> Gestión<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#!">Areas <span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <!-- visible solo para el autorizado a crear area-->
                                            <?php if (\Entrust::can('create-area')) : ?>
                                            <a href="<?php echo e(route('admin.areas.create')); ?>">Nueva</a>
                                            <?php endif; // Entrust::can ?>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.areas.index')); ?>">Todas</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>

                                <li>
                                    <a href="#"><i class="fa fa-users" aria-hidden="true"></i> Trabajadores <span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <!-- visible solo para el autorizado a crear usuarios-->
                                            <?php if (\Entrust::can('create-user')) : ?>
                                            <a href="<?php echo e(route('admin.users.create')); ?>">Nuevo</a>
                                            <?php endif; // Entrust::can ?>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.users.index')); ?>">Todos</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-tasks" aria-hidden="true"></i> Tareas<span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="<?php echo e(route('admin.tasks.create')); ?>">Nueva</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.tasks.index')); ?>">Todas</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.calendar.edit')); ?>"><i class="fa fa-calendar fa-fw"></i> Calendario</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-lock fa-fw" aria-hidden="true"></i> Administración<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#!">Usuarios <span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="<?php echo e(route('admin.users.index')); ?>">Todos</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->
                                </li>
                                <?php if (\Entrust::hasRole('administrador')) : ?>
                                <li>

                                    <a href="#">Accesos <span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="<?php echo e(route('admin.roles.index')); ?>">Roles</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.permissions.index')); ?>">Permisos</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('admin.notifications.index')); ?>">Notificaciones</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level -->

                                </li>
                                <?php endif; // Entrust::hasRole ?>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <?php /*<li <?php echo e((Request::is('*documentation') ? 'class="active"' : '')); ?>>*/ ?>
                            <?php /*<a href="<?php echo e(url ('documentation')); ?>"><i class="fa fa-file-word-o fa-fw"></i> Documentation</a>*/ ?>
                        <?php /*</li>*/ ?>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <!--CONTENIDO DE LA PAGINA-->
        <div id="page-wrapper">
			 <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header"><?php echo $__env->yieldContent('page_heading'); ?></h2>
                </div><!-- /.col-lg-12 -->
             </div>  <!-- /.row -->
			<div class="row">
				<?php echo $__env->yieldContent('section'); ?>
            </div><!-- /.row -->
        </div> <!-- /#page-wrapper -->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plane', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
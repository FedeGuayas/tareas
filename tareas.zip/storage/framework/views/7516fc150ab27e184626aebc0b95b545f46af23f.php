<?php $__env->startSection('page_heading','Crear Categoria de Notificación'); ?>

<?php $__env->startSection('section'); ?>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-lg-6">
                <?php echo Form::open(['route'=>'admin.notifications.store', 'method'=>'POST','role'=>'form']); ?>

                    <div class="form-group">
                        <?php echo Form::label('name','Nombre de la Notificación'); ?>

                        <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'user.follow']); ?>


                    </div>
                    <div class="form-group">
                        <?php echo Form::label('text','Contenido de la notificacion'); ?>

                        <?php echo Form::textarea('text',null,['class'=>'form-control','placeholder'=>'Hola {to.name}, {from.name} es tu seguidor ahora....','rows'=>'3']); ?>

                    </div>
                    <?php echo Form::submit('Crear',['class'=>'btn btn-success','type'=>'button']); ?>

                    <?php echo Form::reset('Limpiar',['class'=>'btn btn-warning']); ?>

                <a href="<?php echo e(route('admin.notifications.index')); ?>" >
                <?php echo Form::button('Regresar',['class'=>'btn btn-primary']); ?>

                </a>
                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('page_heading','Crear Trabajador'); ?>

<?php $__env->startSection('section'); ?>
    <div class="col-sm-12">
        <?php echo $__env->make('alert.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('alert.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-sm-6">
                <?php echo Form::open(['route'=>'admin.persons.store', 'method'=>'POST','role'=>'form']); ?>


                <div class="form-group">
                    <div class="form-inline">
                        <div class="form-group">
                            <div class="form-group">
                                <?php echo Form::label('first_name','Nombre:'); ?>

                                <?php echo Form::text('first_name',null,['class'=>'form-control','placeholder'=>'Nombres','required']); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-group">
                                <?php /*<?php echo Form::label('last_name','Apellidos:'); ?>*/ ?>
                                <?php echo Form::text('last_name',null,['class'=>'form-control','placeholder'=>'Apellidos','required']); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-inline">
                        <div class="form-group">
                            <?php echo Form::label('phone','Teléfono:'); ?>

                            <?php echo Form::text('phone',null,['class'=>'form-control','placeholder'=>'Teléfono']); ?>

                        </div>
                        <div class="input-group">
                            <span class="input-group-addon" id="email-add">@</span>
                            <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'correo@ejemplo.com','aria-describedby'=>'email-add']); ?>

                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="form-inline">
                        <?php echo Form::label('area_id','Area:'); ?>

                        <?php echo Form::select('area_id',$areas,null,['class'=>'form-control','placeholder'=>'Seleccione el area...','required']); ?>

                    </div>
                </div>


                <?php echo Form::submit('Crear',['class'=>'btn btn-success','type'=>'button']); ?>


                <?php echo Form::reset('Limpiar',['class'=>'btn btn-danger']); ?>

                <?php /*<a href="#" >*/ ?>
                <?php /*<?php echo Form::button('Truncate',['class'=>'btn btn-danger']); ?>*/ ?>
                <?php /*</a>*/ ?>

                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
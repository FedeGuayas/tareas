<?php $__env->startSection('page_heading','Crear Tarea'); ?>
<?php $__env->startSection('section'); ?>

    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-6">
                <?php echo $__env->make('alert.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo Form::open(['route'=>'admin.tasks.store', 'method'=>'POST','role'=>'form', 'id'=>'add-event-form']); ?>

                <div class="form-group">
                    <div class="form-group">
                        <?php echo Form::label('task','Tarea:'); ?>

                        <?php echo Form::text('task',null,['class'=>'form-control','placeholder'=>'Nombre de la tarea','required']); ?>

                        <p class="help-block">Ejemplo: Crear este sistema</p>
                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('description','Descripción'); ?>

                    <?php echo Form::textarea('description',null,['class'=>'form-control','placeholder'=>'Breve descripción... puede dejarlo vacio','rows'=>'3']); ?>

                </div>

                <div class="row">
                    <div class='col-sm-6'>
                        <div class="form-group">
                            <?php echo Form::label('start_day','Dia inicio'); ?>

                            <div class='input-group date' id='start_day_datetimepicker'>
                                <?php echo Form::text('start_day',null,['class'=>'form-control','required']); ?>

                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class='col-sm-6'>
                        <div class="form-group">
                            <?php echo Form::label('performance_day','Dia de termino'); ?>

                            <div class='input-group date' id='performance_day_datetimepicker'>
                                <?php echo Form::text('performance_day',null,['class'=>'form-control','required']); ?>

                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="form-inline">
                        <div class="checkbox col-lg-4">
                            <label>
                                <input type="checkbox" name="repeats" id="repeats" value="1"> Tarea recurrente
                            </label>
                        </div>
                        <div id="repeat-options col-lg-4" >
                            <?php /*<label class="radio-inline">*/ ?>
                                <?php /*<input type="radio" value="1" name="repeat-freq" id="1" align="bottom" disabled> diario*/ ?>
                            <?php /*</label>*/ ?>
                            <label class="radio-inline">
                                <input type="radio" value="7" name="repeat-freq" align="bottom" disabled> semanal
                            </label>
                            <label class="radio-inline">
                                <input type="radio" value="30" name="repeat-freq" align="bottom" disabled> mensual
                            </label>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <?php echo Form::label('area_id','Area:'); ?>

                            <?php echo Form::select('area_id',$areas,null,['class'=>'form-control','placeholder'=>'Seleccione area']); ?>

                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <?php echo Form::label('user_id','Trabajador:'); ?>

                            <?php echo Form::select('user_id',['placeholder'=>'Seleccione trabajador'],null,['class'=>'form-control']); ?>

                        </div>
                    </div>
                </div>


<div class="pull-right">
    <div class="clearfix"></div>
    <br>
    <?php echo Form::submit('Crear',['class'=>'btn btn-success','type'=>'button']); ?>

    <?php echo Form::reset('Limpiar',['class'=>'btn btn-danger']); ?>


</div>

                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <?php /*Script para select condicional dropdown de personas por areas*/ ?>
    <script src="<?php echo e(asset("assets/scripts/dropdown.js")); ?>" type="text/javascript"></script>

    <script type="text/javascript">
        $(function () {
            $('#start_day_datetimepicker').datetimepicker({
                daysOfWeekDisabled: [0, 6],
                showClear:true,
                showClose:true,
                minDate: moment(),
                enabledHours: [9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
                locale:'es',
                format:'YYYY-MM-DD HH:mm:ss'

            });
            $('#performance_day_datetimepicker').datetimepicker({
                daysOfWeekDisabled: [0, 6],
                showClear:true,
                showClose:true,
                useCurrent: false, //Important! See issue #1075
                enabledHours: [9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
                locale:'es',
                format:'YYYY-MM-DD HH:mm:ss'

            });
            $("#start_day_datetimepicker").on("dp.change", function (e) {
                $('#performance_day_datetimepicker').data("DateTimePicker").minDate(e.date);

            });
            $("#performance_day_datetimepicker").on("dp.change", function (e) {
                $('#start_day_datetimepicker').data("DateTimePicker").maxDate(e.date);
            });


            $("#repeats").on('click',function(){
                if($("#repeats").prop("checked")){
                    $("input[type=radio][name=repeat-freq]").prop("disabled", false);
                }else{
                    $("input[type=radio][name=repeat-freq]").prop("disabled",true);
                    $("input[type=radio][name=repeat-freq]").prop("checked",false);
                }

            });
        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
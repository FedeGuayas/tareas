<?php echo Form::open (['route' => 'admin.reports.index','method' => 'GET' ]); ?>

<div class='col-sm-3'>
    <div class="form-group">
        <?php echo Form::label('start','Desde'); ?>

        <div class='input-group date' id='start_datetimepicker'>
            <?php echo Form::text('start',$start,['class'=>'form-control']); ?>

                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                        </span>
        </div>
    </div>
</div>
<div class='col-sm-3'>
    <div class="form-group">
        <?php echo Form::label('end','Hasta'); ?>

        <div class='input-group date' id='end_datetimepicker'>
            <?php echo Form::text('end',$end,['class'=>'form-control']); ?>

                        <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
            </span>
        </div>
    </div>
</div>

<?php /*<div class="clearfix"></div>*/ ?>
<div class="col-sm-3">
<?php echo Form::submit('Buscar',['class'=>'btn btn-primary']); ?>

</div>
<?php /*<div class="col-sm-3">*/ ?>

<?php /*</div><!-- /.col-lg-3 -->*/ ?>

<?php /*<div class="col-sm-3">*/ ?>
    <?php /*<div class="form-group">*/ ?>
        <?php /*<?php echo Form::label('buscar','Buscar'); ?>*/ ?>
        <?php /*<div class="input-group">*/ ?>
            <?php /*<?php echo Form::select('trabajador',$trabajadores,$trabajador,['placeholder'=>'Seleccione trabajador','class'=>'form-control','id'=>'trabajador']); ?>*/ ?>
                    <?php /*<span class="input-group-btn">*/ ?>
                        <?php /*<a href=""  class="btn btn-primary" title="Buscar"><i class="fa fa-search" aria-hidden="true"></i>*/ ?>
                            <?php /*<?php echo Form::submit('Buscar',['class'=>'btn btn-primary']); ?>*/ ?>
                        <?php /*</a>*/ ?>
                    <?php /*</span>*/ ?>
        <?php /*</div><!-- /input-group -->*/ ?>
    <?php /*</div>*/ ?>
<?php /*</div><!-- /.col-lg-3 -->*/ ?>
<?php echo form::close(); ?>


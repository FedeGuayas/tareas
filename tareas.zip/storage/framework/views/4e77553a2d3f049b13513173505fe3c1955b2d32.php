<?php $__env->startSection('page_heading', 'Asignar Permisos al '.$rol->display_name); ?>

<?php $__env->startSection('section'); ?>


    <div class="row">
        <div class="col l12 m12 s12">
            <?php echo Form::open(['route'=>'admin.roles.setpermisos', 'method'=>'POST']); ?>

            <?php echo Form::hidden('rol_id',$rol->id); ?>

            <table class="table table-striped table-bordered table-condensed table-hover highlight responsive-table">
                <thead>
                    <?php /*<th>Id</th>*/ ?>
                    <th>Add/Rem</th>
                    <th>Permisos</th>
                    <th>Descripcion</th>

                </thead>
                <?php foreach($permisos as $per): ?>
                    <tr>
                        <?php /*<td><?php echo e($per->id); ?></td>*/ ?>
                        <td><?php echo Form::checkbox('permisos[]',$per->id,false,['id'=>$per->id]); ?>

                            <?php echo Form::label($per->id, $per->name); ?>

                        <td><?php echo e($per->display_name); ?></td>
                        <td><?php echo e($per->description); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table><!--end table-responsive-->
            <?php echo Form::button('Otorgar<i class="fa fa-play right"></i>', ['class'=>'btn waves-effect waves-light','type' => 'submit']); ?>

            <?php echo Form::button('Cancelar<i class="fa fa-close right"></i>',['class'=>'btn waves-effect waves-light red darken-1','type' => 'reset']); ?>

            <a href="<?php echo e(route('admin.roles.index')); ?>"  class="tooltipped" data-position="top" data-delay="50" data-tooltip="Regresar">
                <?php echo Form::button('<i class="fa fa-undo"></i>',['class'=>'btn waves-effect waves-light darken-1']); ?>

            </a>
            <?php echo Form::open(); ?>

        </div><!--end div ./col-lg-12. etc-->
    </div><!--end div ./row-->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<html>
    <body>
    <div>
        <h3><b><?php echo e($receiver->getFullName()); ?></b></h3><hr>

        <b> <?php echo e($sender->getFullname()); ?></b> , ha creado un nuevo evento para ud en el sistema de Gestión de Tareas de FEDEGUAYAS.
        <br>

        <div>

        <p>

            Tarea: <?php echo e($task->task); ?><br>

            Descripción: <?php echo e($task->description); ?><br>

            Creada el: <?php echo e($task->created_at); ?><br>

            Fecha inicio<?php echo e($task->start_day); ?><br>

            Fecha termino<?php echo e($task->performance_day); ?><br>

        </p>

            <a href="<?php echo e(route('home')); ?>">Entrar</a>
        </div>

        Atentamente, Dpto Administrativo.
    </div>
    </body>
</html>
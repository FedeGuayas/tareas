<?php $__env->startSection('page_heading','Listado Trabajadores'); ?>

<?php $__env->startSection('section'); ?>

    <div class="col-sm-12">
        <div class="row">
            <div class="col-lg-10 col-lg-offset-1">
                <?php echo $__env->make('alert.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table id="users_table" class="table table-striped table-bordered" cellspacing="0" width="100%"
                       data-order='[[ 1, "asc" ]]' style="display: none">
                    <thead>
                    <tr>
                        <?php /*<th>id</th>*/ ?>
                        <th>Usuario</th>
                        <th>Nombre</th>
                        <th>Telefono</th>
                        <th>Email</th>
                        <th>Area</th>
                        <th>Tareas</th>
                        <th>Acción</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <?php /*<th>id</th>*/ ?>
                        <th>Usuario</th>
                        <th>Nombre</th>
                        <th>Telefono</th>
                        <th>Email</th>
                        <th>Area</th>
                        <th>Tareas</th>
                        <th>Acción</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php foreach($users as $user): ?>
                        <tr>
                            <?php /*<td><?php echo e($area->id); ?></td>*/ ?>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->getFullName()); ?></td>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->area['area']); ?></td>
                            <td>
                                <a href="#!" class="btn btn-xs bg-info">Total  <span class="badge"><?php echo e($user->tasks->count()); ?></span></a>

                                <?php foreach($user->tasks as $task): ?>
                                    <?php if($task->repeats==1): ?><?php /*repetitiva*/ ?>
                                        <a href="#!" class="btn btn-xs bg-primary">Recurrentes <span class="badge"><?php echo e($task->events->count()); ?></span></a>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.users.edit', $user->id )); ?>" class="btn btn-xs btn-warning tip" data-placement="top" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>
                                <a href="" data-target="#modal-delete-<?php echo e($user->id); ?>" data-toggle="modal" class="btn btn-xs btn-danger tip"  data-placement="top" title="Elimminar"><i class="fa fa-trash" aria-hidden="true"></i>
                                </a>
                                <?php if (\Entrust::can('create-role')) : ?>
                                <a href="<?php echo e(route('admin.users.roles', $user->id )); ?>" class="btn btn-xs btn-warning tip" data-placement="top" title="Roles"><i class="fa fa-key" aria-hidden="true"></i>
                                </a>
                                <?php endif; // Entrust::can ?>
                            </td>
                        </tr>
                        <?php echo $__env->make('users.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endforeach; ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script type="text/javascript">

        $(document).ready( function () {

            var table =  $('#users_table').DataTable({
                "lengthMenu": [[5, 7, 10, 25], [5, 7, 10, 25]],
                "processing": true,
//            "serverSide": false,
//            "ajax":"api/result",
//            "columns":[
//                {data:'first_name'},
//                {data:'second_name'},
//                {data:'last_name'},
//                {data:'sex'},
//                {data:'category'},
//                {data:'circuit'},
//                {data:'place'},
//                {data:'time'},
//            ],
//            select: true
                "language":{
                    "decimal":        "",
                    "emptyTable":     "No se encontraron datos en la tabla",
                    "info":           "Mostrando _START_ a _END_ de _TOTAL_ registros",
                    "infoEmpty":      "Mostrando 0 a 0 de 0 registros",
                    "infoFiltered":   "(filtrados de un total _MAX_ registros)",
                    "infoPostFix":    "",
                    "thousands":      ",",
                    "lengthMenu":     "Mostrar _MENU_ registros",
                    "loadingRecords": "Cargando...",
                    "processing":     "Procesando...",
                    "search":         "Buscar:",
                    "zeroRecords":    "No se encrontraron coincidencias",
                    "paginate": {
                        "first":      "Primero",
                        "last":       "Ultimo",
                        "next":       "Siguiente",
                        "previous":   "Anterior"
                    },
                    "aria": {
                        "sortAscending":  ": Activar para ordenar ascendentemente",
                        "sortDescending": ": Activar para ordenar descendentemente"
                    }
                },
                "fnInitComplete":function(){
                    $('#users_table').fadeIn();
                }
            });


            $(function () {
                $('.tip').tooltip()
            });

        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
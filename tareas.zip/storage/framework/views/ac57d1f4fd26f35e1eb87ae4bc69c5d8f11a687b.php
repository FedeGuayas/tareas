<?php $__env->startSection('page_heading', 'Crear Permiso'); ?>

<?php $__env->startSection('section'); ?>


    <div class="row">
        <?php echo Form::open(['route'=>'admin.permissions.store', 'method'=>'POST']); ?>


        <div class="col-lg-10 col-md-8 col-sm-12">
            <div class="form-horizontal">

                <div class="form-group">
                    <?php echo Form::label('name','Nombre del permiso:',['class'=>'control-label col-sm-2']); ?>

                    <div class="col-lg-6">
                        <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>' Ejemplo: "create-task", "edit-task"']); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('display_name','Nombre a mostrar:',['class'=>'control-label col-lg-2']); ?>

                    <div class="col-lg-6">
                        <?php echo Form::text('display_name',null,['class'=>'form-control','placeholder'=>' Ejemplo: "Crear Tareas", "Editar Tareas",']); ?>

                    </div>
                </div>

                <div class="form-group">
                    <?php echo Form::label('description','Descripción',['class'=>'control-label col-lg-2']); ?>

                    <div class="col-lg-6">
                        <?php echo Form::textarea('description',null,['class'=>'form-control','rows'=>'3']); ?>

                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">

                        <?php echo Form::button('<i class="fa fa-check fa-fw" aria-hidden="true"></i>Crear', ['class'=>'btn btn-success','type' => 'submit']); ?>

                        <?php echo Form::button('<i class="fa fa-close fa-fw" aria-hidden="true"></i>Cancelar',['class'=>'btn btn-warning','type' => 'reset']); ?>


                    </div>
                </div>
            </div>


        </div>

        <?php echo Form::close(); ?>

    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>